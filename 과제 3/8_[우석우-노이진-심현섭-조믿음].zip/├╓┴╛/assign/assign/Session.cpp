#include "Session.h"

LoginInfo g_loginInfo;